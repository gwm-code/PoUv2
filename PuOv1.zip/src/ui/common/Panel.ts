// Hard NO-OP: inner frame is retired
export function drawInnerFrame(_ctx: CanvasRenderingContext2D, _r:{x:number,y:number,w:number,h:number}) {}
